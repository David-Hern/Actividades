package modelo;

public class Modelo {
    
    //Aqui se crean las variables a utilizar para crear el metodo de get and set
    private int numeroUno;
    private int numeroDos;
    private int resultado;

    //Aqui se crean los metodos de get and set
    public int getNumeroUno() {
        return numeroUno;
    }

    public void setNumeroUno(int numeroUno) {
        this.numeroUno = numeroUno;
    }

    public int getNumeroDos() {
        return numeroDos;
    }

    public void setNumeroDos(int numeroDos) {
        this.numeroDos = numeroDos;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }
    
    //aqui se realiza el calculo y se retorna el resultado.
    public int multiplicar(){
        
        this.resultado = this.numeroUno * this.numeroDos;
        return this.resultado;
        
    }
}
