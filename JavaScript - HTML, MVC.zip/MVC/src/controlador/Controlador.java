package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Modelo;
import vista.Vista;

public class Controlador implements ActionListener{
    
    //Aqui se importa vista y modelo
    private Vista view;
    private Modelo model;
    
    //Constructor que recibe los parametros de vista y modelo
    public Controlador(Vista view, Modelo model){
        
        this.view = view;
        this.model = model;
        this.view.btnMultiplicar.addActionListener(this);
        
    }
    //aqui se va a iniciar vista
    public void iniciar(){
        
        view.setTitle("MVC Multiplicar");
        view.setLocationRelativeTo(null);
        
    }
    
    //Aqui se campura el texto, el valor introducido se convierte en entero y se muestra el resultado.
    public void actionPerformed(ActionEvent e){
        
        model.setNumeroUno(Integer.parseInt(view.txtNumeroUno.getText()));
        model.setNumeroDos(Integer.parseInt(view.txtNumeroDos.getText()));
        model.multiplicar();
        view.txtResultado.setText(String.valueOf(model.getResultado()));
        
    }
}
